package com.test.demo;

import java.util.Locale;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.web.servlet.WebMvcProperties.LocaleResolver;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	
	/*
	 * @Bean public SessionLocaleResolver localeResolver() {
	 * 
	 * SessionLocaleResolver localeResolver = new SessionLocaleResolver();
	 * localeResolver.setDefaultLocale(Locale.US); return localeResolver; }
	 */
	
	@Bean
	public AcceptHeaderLocaleResolver localeResolver() {
		
		AcceptHeaderLocaleResolver localeResolver =  new AcceptHeaderLocaleResolver();
		localeResolver.setDefaultLocale(Locale.US);
		return localeResolver;
	}
	
	
	
	@Bean
	public ResourceBundleMessageSource bundleMessageResource() {
		
		ResourceBundleMessageSource resourceBundle =  new ResourceBundleMessageSource();
		//Move this setting in application property
		//resourceBundle.setBasename("messages");
		return resourceBundle;
	}
}
