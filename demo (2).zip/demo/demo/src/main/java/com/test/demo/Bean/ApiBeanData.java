package com.test.demo.Bean;

public class ApiBeanData {
	
	private String message;
	
	public ApiBeanData(String message){
		this.message=message;
		
		
		
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "ApiBeanData [message=" + message + "]";
	}

}
