package com.test.demo.Bean.Dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Component;

import com.test.demo.Bean.User;

@Component
public class UserDaoService {

	private static List<User> userList = new ArrayList<User>();

	static {
		userList.add(new User(1, "Amit", new Date()));

		userList.add(new User(2, "Sushil", new Date()));
		userList.add(new User(3, "Hemandra", new Date()));

	}

	public List<User> findAllUsers() {

		return userList;
	}

	public User saveUser(User user) {

		this.userList.add(user);
		return user;
	}

	public User findUsers(Integer id) {

		for (User user : this.userList) {

			if (user.getId() == id) {
				return user;
			}
		}
		return null;
	}

	public User deleteUser(Integer id) {

		Iterator<User> userItr = this.userList.iterator();

		while (userItr.hasNext()) {
			User user = userItr.next();

			if (user.getId() == id) {
				userList.remove(user);
				return user;
			}

		}
		return null;
	}

}
