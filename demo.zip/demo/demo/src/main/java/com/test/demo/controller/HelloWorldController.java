package com.test.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.test.demo.Bean.ApiBeanData;

//Controller
@RestController
public class HelloWorldController {
	
	//GET
//  /getApiData
	
	
	@RequestMapping(method=RequestMethod.GET, path="/getApiData")
	public String getApiData() {
		
		return "uri";
	}
	
	@GetMapping( path="/getApiBean")
	public  ApiBeanData getApiBean() {
		
		return new ApiBeanData("Bean Data");
	}
	
	@GetMapping( path="/getApiBeanwithParam/pathParam/{name}")
	public  ApiBeanData getApiBean(@PathVariable String name) {
		
		return new ApiBeanData("Bean Data");
	}

}
