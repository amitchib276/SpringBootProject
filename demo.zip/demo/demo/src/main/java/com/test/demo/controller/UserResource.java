package com.test.demo.controller;

import java.net.URI;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.test.demo.Bean.User;
import com.test.demo.Bean.Dao.UserDaoService;
import com.test.demo.controller.Exception.UserNotFoundException;

@RestController
public class UserResource {

	@Autowired
	UserDaoService userServiceDao;

	// get All Users
	@GetMapping(path = "/getAllUsers")
	public List<User> getAllUsers() {

		return userServiceDao.findAllUsers();

	}

	// get specific User
	@GetMapping(path = "/getUser/userId/{id}")
	public User getSpecifiUser(@PathVariable int id) {

		if (userServiceDao.findUsers(id) == null) {

			throw new UserNotFoundException("id" + id);
		}

		return userServiceDao.findUsers(id);

	}

	@PostMapping(path = "/saveUser")
	public ResponseEntity<Object> getSpecifiUser(@Valid @RequestBody User user) {

		User userSaved = userServiceDao.saveUser(user);
		if (userSaved == null) {

			throw new UserNotFoundException("id" +user.getId());
		}

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(userSaved.getId())
				.toUri();
		return ResponseEntity.created(location).build();

	}

	@DeleteMapping(path = "/deleteUser/{id}")
	public void deleteUser(@PathVariable int id) {

		User userSaved = userServiceDao.deleteUser(id);

		if (userSaved == null) {

			throw new UserNotFoundException("id" + id);
		}

	}

}
